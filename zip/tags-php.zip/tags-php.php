<?php

    echo "<h1>Bem-vindo ao curso de PHP 8</h1>";
