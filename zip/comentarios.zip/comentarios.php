<?php

//Este é um comentário de linha

//echo "Hcode";

/*
    function somar() {
        return 2 + 2;
        
    }
*/

/**
 * Normal
 * * Comentário destacado
 * ! COmentário de alerta
 * ? Dúvida
 * TODO: A fazer
 * @param nome Informar o nome da pessoa
 * 
 * 
 * 
 * 
 */