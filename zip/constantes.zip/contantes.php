<?php

define("CURSO", "PHP 8 da Hcode Treinamentos");

echo CURSO;