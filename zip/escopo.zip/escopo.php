<?php

function exibir(){

    global $hcode;
    $hcode = "https://hcode.com.br";

}

exibir();

echo $hcode;