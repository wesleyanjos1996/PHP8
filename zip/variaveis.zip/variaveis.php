<?php

$primeiroNome = "João";
$ultimoNome = "Rangel";

$nomeCompleto = $primeiroNome . " " . $ultimoNome;

/*
echo $primeiroNome;
echo "<br/>";
echo $ultimoNome;
echo "<br/>";
echo $nomeCompleto;
*/

var_dump($primeiroNome);
var_dump($ultimoNome);
var_dump($nomeCompleto);